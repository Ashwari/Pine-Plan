package com.example.todolistapp.tasks

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.todolistapp.R
import com.example.todolistapp.adapters.CategoryAdapter
import com.example.todolistapp.databinding.ActivityTaskCategoryBinding
import com.example.todolistapp.models.CategoryModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class TaskCategoryActivity : AppCompatActivity() {

    private var clicked = false
    private lateinit var binding: ActivityTaskCategoryBinding
    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var categoryArrayList: ArrayList<CategoryModel>
    private lateinit var categoryAdapter: CategoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val actionbar = supportActionBar
        actionbar!!.title = "Pine Plan"
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

        firebaseAuth = FirebaseAuth.getInstance()
        loadCategories()

        val addBtn = findViewById<FloatingActionButton>(R.id.st_floatingActionButton)
        addBtn.setOnClickListener {
            val intent = Intent(this, AddTaskCategoryActivity::class.java)
            startActivity(intent)
        }
    }
    private fun loadCategories() {
        categoryArrayList = ArrayList()
        val ref = FirebaseDatabase.getInstance().getReference("Task Categories")
        ref.addValueEventListener(object  : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                categoryArrayList.clear()
                for(ds in snapshot.children){
                    val model = ds.getValue(CategoryModel::class.java)
                    categoryArrayList.add(model!!)
                }
                categoryAdapter = CategoryAdapter(this@TaskCategoryActivity, categoryArrayList)

                binding.RvCat.adapter = categoryAdapter
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })

    }

}