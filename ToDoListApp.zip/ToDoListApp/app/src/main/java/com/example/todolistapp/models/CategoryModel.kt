package com.example.todolistapp.models

class CategoryModel {

    var id : String = ""
    var category : String = ""

    constructor()

    constructor(id: String, category: String) {
        this.id = id
        this.category = category
    }


}