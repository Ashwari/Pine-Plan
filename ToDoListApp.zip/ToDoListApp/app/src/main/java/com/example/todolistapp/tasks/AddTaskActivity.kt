package com.example.todolistapp.tasks

import android.app.AlertDialog
import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.todolistapp.R
import com.example.todolistapp.databinding.ActivityAddTaskBinding
import com.example.todolistapp.models.CategoryModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.HashMap

class AddTaskActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddTaskBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var progressDialog: ProgressDialog

    private lateinit var categoryArrayList: ArrayList<CategoryModel>
    private val TAG = "ADDED"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val actionbar = supportActionBar
        actionbar!!.title = "Pine Plan"
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

        firebaseAuth = FirebaseAuth.getInstance()
        loadTaskCat()

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please Wait...")
        progressDialog.setCanceledOnTouchOutside(false)

        binding.categoryTV.setOnClickListener {
            categoryPickDialog()
        }
        binding.taskBtn.setOnClickListener {
            validateData()
        }
    }

    private var Task = ""
    private var Category = ""

    private fun validateData() {
        Log.d(TAG, "validateData: Validating Data")

        Task = binding.TaskEt.text.toString().trim()
        Category = binding.categoryTV.text.toString().trim()

        if (Task.isEmpty()) {
            Toast.makeText(this, "Enter Task...", Toast.LENGTH_SHORT).show()
        } else if (Category.isEmpty()) {
            Toast.makeText(this, "Enter Category...", Toast.LENGTH_SHORT).show()
        } else {
            uploadTask()
        }
    }

    private fun uploadTask() {

        Log.d(TAG, "uploadStock: Uploading to Database")
        progressDialog.show()


        val timestamp = System.currentTimeMillis()

        val hashMap: HashMap<String, Any> = HashMap()
        hashMap["ID"] = "$timestamp"
        hashMap["Task"] = Task
        hashMap["Category"] = selectedCategoryId


        val ref = FirebaseDatabase.getInstance()
            .getReference("Tasks")//this is the table you saving it under
        ref.child("$timestamp")
            .setValue(hashMap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Added Successfully!!", Toast.LENGTH_SHORT).show()
                binding.TaskEt.text.clear()

            }
            .addOnFailureListener { e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to add due to ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadTaskCat() {
        Log.d(TAG, "LoadStockCat: Loading Task Categories")

        categoryArrayList = java.util.ArrayList()
        val ref = FirebaseDatabase.getInstance().getReference("Task Categories")
        ref.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                categoryArrayList.clear()
                for (ds in snapshot.children) {
                    val model = ds.getValue(CategoryModel::class.java)
                    categoryArrayList.add(model!!)
                    Log.d(TAG, "onDataChange: ${model.category}")
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }
        })
    }

    private var selectedCategoryId = ""
    private var selectedTitle = ""
    private fun categoryPickDialog() {
        Log.d(TAG, "categoryPickDialog: Showing Task Category Pick Dialog")
        val categoryArray = arrayOfNulls<String>(categoryArrayList.size)
        for (i in categoryArray.indices) {
            categoryArray[i] = categoryArrayList[i].category
        }
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Pick Categories")
            .setItems(categoryArray) { dialog, which ->
                selectedTitle = categoryArrayList[which].category
                selectedCategoryId = categoryArrayList[which].id

                binding.categoryTV.text = selectedTitle
                Log.d(TAG, "categoryPickDialog: Selected Category ID: $selectedCategoryId")
                Log.d(TAG, "categoryPickDialog: Selected Category Title: $selectedTitle")
            }
            .show()

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}