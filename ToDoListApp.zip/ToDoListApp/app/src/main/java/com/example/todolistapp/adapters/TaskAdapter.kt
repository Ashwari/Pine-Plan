package com.example.todolistapp.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.todolistapp.databinding.RowListBinding
import com.example.todolistapp.models.TaskModel

class TaskAdapter : RecyclerView.Adapter<TaskAdapter.HolderTask> {
    private var context: Context
    var taskArrayList: ArrayList<TaskModel>
    private lateinit var binding: RowListBinding


    constructor(context: Context, taskArrayList: ArrayList<TaskModel>) : super() {
        this.context = context
        this.taskArrayList = taskArrayList
    }

    inner class HolderTask(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTaskName = binding.checkBox
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderTask {
        binding = RowListBinding.inflate(LayoutInflater.from(context), parent, false)
        return HolderTask(binding.root)
    }

    override fun getItemCount(): Int {
        return taskArrayList.size
    }

    override fun onBindViewHolder(holder: HolderTask, position: Int) {
        val model = taskArrayList[position]
        val taskId = model.ID
        val taskName = model.Task

        holder.tvTaskName.text = taskName
        holder.tvTaskName.isChecked =
            model.isChecked // Update checkbox state based on isChecked property

        holder.tvTaskName.setOnCheckedChangeListener { _, isChecked ->
            // Update the isChecked property of the task model when checkbox state changes
            model.isChecked = isChecked
        }
    }
}


