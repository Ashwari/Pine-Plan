package com.example.todolistapp.adapters

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.todolistapp.databinding.RowCategoryBinding
import com.example.todolistapp.models.CategoryModel
import com.example.todolistapp.tasks.TaskActivity
import com.google.firebase.database.FirebaseDatabase

 class CategoryAdapter : RecyclerView.Adapter<CategoryAdapter.HolderCategory>{

    private val context: Context
    var categoryArrayList: ArrayList<CategoryModel>
    private lateinit var binding: RowCategoryBinding

    constructor(context: Context, categoryArrayList: ArrayList<CategoryModel>){
        this.context = context
        this.categoryArrayList = categoryArrayList
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderCategory {
        binding = RowCategoryBinding.inflate(LayoutInflater.from(context), parent,false)
        return HolderCategory(binding.root)
    }

    override fun getItemCount(): Int {
        return categoryArrayList.size
    }

    override fun onBindViewHolder(holder: HolderCategory, position: Int) {
        val model = categoryArrayList[position]
        val id = model.id
        val category = model.category

        holder.categoryTv.text = category

        holder.deleteBtn.setOnClickListener {
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Delete")
                .setMessage("Are You Sure All Tasks Have Been Completed?")
                .setPositiveButton("Confirm"){a, d->
                    Toast.makeText(context, "Deleting...",Toast.LENGTH_SHORT).show()
                deleteCategory(model, holder)

                }
                .setNegativeButton("Cancel"){a, d->
                    a.dismiss()
                }
                .show()
        }
        holder.itemView.setOnClickListener {
           val intent = Intent(context, TaskActivity::class.java)
            intent.putExtra("CategoryId", id)
            intent.putExtra("Category", category)
            context.startActivity(intent)

        }
   }

    private fun deleteCategory(model: CategoryModel, holder: HolderCategory) {
        val id = model.id
        val ref = FirebaseDatabase.getInstance().getReference("Task Categories")
        ref.child(id)
            .removeValue()
            .addOnSuccessListener {
                Toast.makeText(context, "Deleted!!!",Toast.LENGTH_SHORT).show()

            }
            .addOnFailureListener{ e->
                Toast.makeText(context, "Unable To Delete Due To ${e.message}",Toast.LENGTH_SHORT).show()

            }

    }

    inner class HolderCategory(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var categoryTv: TextView = binding.TvCat
        var deleteBtn: ImageButton = binding.deleteBtn
    }
}

