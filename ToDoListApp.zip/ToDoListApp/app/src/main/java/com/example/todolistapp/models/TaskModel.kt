package com.example.todolistapp.models

class TaskModel {
    var ID:String = ""
    var Task:String =""
    var CategoryID:String = ""
    var isChecked: Boolean = false

    constructor()
    constructor(
        ID: String,
        Task: String,
        CategoryID: String
    ) {
        this.ID = ID
        this.Task = Task
        this.CategoryID = CategoryID
    }


}