package com.example.todolistapp.tasks


import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.todolistapp.R
import com.example.todolistapp.adapters.TaskAdapter
import com.example.todolistapp.databinding.ActivityTaskBinding
import com.example.todolistapp.models.TaskModel
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class TaskActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTaskBinding
    private var categoryId = ""
    private var category = ""
    private companion object {
        const val TAG = "TASK_LIST_TAG"
    }

    private lateinit var taskArrayList: ArrayList<TaskModel>
    private lateinit var taskAdapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val actionbar = supportActionBar
        actionbar!!.title = "Pine Plan"
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

        val intent = intent
        categoryId = intent.getStringExtra("CategoryId")!!
        category = intent.getStringExtra("Category")!!

        loadTaskList()

        val addBtn = findViewById<FloatingActionButton>(R.id.st_floatingActionButton)
        addBtn.setOnClickListener {
            val intent = Intent(this, AddTaskActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loadTaskList() {

       taskArrayList = ArrayList()

        val ref = FirebaseDatabase.getInstance().getReference("Tasks")
        ref.orderByChild("Category").equalTo(categoryId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    taskArrayList.clear()
                    for (ds in snapshot.children) {
                        val model = ds.getValue(TaskModel::class.java)
                        if (model != null) {
                            taskArrayList.add(model)
                            Log.d(TAG, "onDataChange: ${model.Task} ${model.CategoryID}")
                        }
                    }
                    taskAdapter = TaskAdapter(this@TaskActivity, taskArrayList)
                    binding.RvTask.adapter = taskAdapter
                }

                override fun onCancelled(error: DatabaseError) {

                }
            })
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

}